// --- CSV Fetch Helper (using PapaParse for all CSVs) ---
function fetchCSV(url) {
  return new Promise((resolve, reject) => {
    if (!window.Papa) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/papaparse@5.4.1/papaparse.min.js';
      script.onload = () => fetchCSV(url).then(resolve).catch(reject);
      document.head.appendChild(script);
      return;
    }
    window.Papa.parse(url, {
      download: true,
      header: true,
      complete: results => resolve(results.data),
      error: err => reject(err)
    });
  });
}

// Fix: define handleItemClick to prevent crash
  function handleItemClick(type, item, idx) {
    if (window.highlightMapFeature) {
      window.highlightMapFeature(type, item, idx);
    } else {
      // Placeholder: just alert for now
      alert('Highlight logic not yet implemented.');
    }
  }
// React hooks
const { useEffect, useRef, useState } = React;

// --- Marker/cluster color options and SVG helper ---
const COLOR_OPTIONS = [
  { name: 'Violet', gradient: 'linear-gradient(135deg,#a259c4 0%,#7b2ff2 100%)', solid: '#a259c4' },
  { name: 'Blue', gradient: 'linear-gradient(135deg,#2196f3 0%,#21cbf3 100%)', solid: '#2196f3' },
  { name: 'Green', gradient: 'linear-gradient(135deg,#56ab2f 0%,#a8e063 100%)', solid: '#56ab2f' },
  { name: 'Orange', gradient: 'linear-gradient(135deg,#f7971e 0%,#ffd200 100%)', solid: '#f7971e' },
  { name: 'Red', gradient: 'linear-gradient(135deg,#f85032 0%,#e73827 100%)', solid: '#f85032' },
  { name: 'Teal', gradient: 'linear-gradient(135deg,#136a8a 0%,#267871 100%)', solid: '#136a8a' },
  { name: 'Pink', gradient: 'linear-gradient(135deg,#f953c6 0%,#b91d73 100%)', solid: '#f953c6' }
];

function getMarkerSVG(shape, size, color, opacity) {
  switch (shape) {
    case 'hexagon': {
      // Regular hexagon centered in 18x18 viewBox
      const hexPoints = "9,2 16,6.5 16,14 9,17 2,14 2,6.5";
      return `<svg width="${size}" height="${size}" viewBox="0 0 18 18"><polygon points="${hexPoints}" fill="${color}" fill-opacity="${opacity}"/></svg>`;
    }
    case 'triangle':
      return `<svg width="${size}" height="${size}" viewBox="0 0 18 18"><polygon points="9,3 16,15 2,15" fill="${color}" fill-opacity="${opacity}"/></svg>`;
    case 'square':
      return `<svg width="${size}" height="${size}" viewBox="0 0 18 18"><rect x="3" y="3" width="12" height="12" fill="${color}" fill-opacity="${opacity}"/></svg>`;
    default:
      return `<svg width="${size}" height="${size}" viewBox="0 0 18 18"><circle cx="9" cy="9" r="8" fill="${color}" fill-opacity="${opacity}"/></svg>`;
  }
}

function createDivIcon(shape, markerSize, markerColorIdx, markerOpacity, type) {
  const baseSize = 18; // Use a fixed base SVG size
  const color = COLOR_OPTIONS[markerColorIdx]?.solid || COLOR_OPTIONS[0].solid;
  let svg = '';
  if (type === 'inscription') {
    svg = `<svg class="marker-svg" width="${baseSize}" height="${baseSize}" viewBox="0 0 18 18"><rect x="3" y="3" width="12" height="12" fill="${color}" fill-opacity="${markerOpacity}"/></svg>`;
  } else if (shape === 'hexagon') {
    const hexPoints = "9,2 16,6.5 16,14 9,17 2,14 2,6.5";
    svg = `<svg class="marker-svg" width="${baseSize}" height="${baseSize}" viewBox="0 0 18 18"><polygon points="${hexPoints}" fill="${color}" fill-opacity="${markerOpacity}"/></svg>`;
  } else if (shape === 'triangle') {
    svg = `<svg class="marker-svg" width="${baseSize}" height="${baseSize}" viewBox="0 0 18 18"><polygon points="9,3 16,15 2,15" fill="${color}" fill-opacity="${markerOpacity}"/></svg>`;
  } else if (shape === 'square') {
    svg = `<svg class="marker-svg" width="${baseSize}" height="${baseSize}" viewBox="0 0 18 18"><rect x="3" y="3" width="12" height="12" fill="${color}" fill-opacity="${markerOpacity}"/></svg>`;
  } else {
    svg = `<svg class="marker-svg" width="${baseSize}" height="${baseSize}" viewBox="0 0 18 18"><circle cx="9" cy="9" r="8" fill="${color}" fill-opacity="${markerOpacity}"/></svg>`;
  }
  // Use CSS transform: scale to resize
  const scale = (markerSize || baseSize) / baseSize;
  return L.divIcon({
    className: 'custom-marker',
    iconSize: [baseSize, baseSize],
    iconAnchor: [baseSize / 2, baseSize / 2],
    html: `<div style="transform:scale(${scale});transform-origin:center;">${svg}</div>`
  });
}

// New: create cluster icon for temples (orange triangle background)
function createTempleClusterIcon(count, markerColorIdx) {
  const size = count < 10 ? 36 : count < 100 ? 48 : 60;
  // Dynamically scale font size to fit well within hexagon, with free space
  let fontSize;
  const countLength = String(count).length;
  if (size === 36) {
    fontSize = countLength === 1 ? 13 : countLength === 2 ? 10 : 8;
  } else if (size === 48) {
    fontSize = countLength === 1 ? 17 : countLength === 2 ? 13 : 10;
  } else {
    fontSize = countLength === 1 ? 22 : countLength === 2 ? 16 : 12;
  }
  // Hexagon points for a regular hexagon centered in 36x36 viewBox
  const hexPoints = "18,4 32,12 32,28 18,36 4,28 4,12";
  // Use selected color for cluster background
  const fillColor = COLOR_OPTIONS[markerColorIdx]?.solid || COLOR_OPTIONS[0].solid;
  // Center text exactly: x=18, y=20 (center of 36x36), use alignment-baseline and dominant-baseline middle
  const hexSVG = `<svg width="${size}" height="${size}" viewBox="0 0 36 36"><polygon points="${hexPoints}" fill="${fillColor}" stroke="#fff" stroke-width="1.5"/><text x="18" y="20" text-anchor="middle" font-size="${fontSize}" fill="#111" font-weight="bold" alignment-baseline="middle" dominant-baseline="middle" font-family="Arial, 'Helvetica Neue', Helvetica, sans-serif">${count}</text></svg>`;
  return L.divIcon({
    html: hexSVG,
    className: 'temple-cluster-icon',
    iconSize: [size, size]
  });
}

function createClusterIcon(count, markerColorIdx, type) {
  if (type === 'temple') {
    return createTempleClusterIcon(count, markerColorIdx);
  }
  const size = count < 10 ? 36 : count < 100 ? 48 : 60;
  // Use solid color for clusters to match marker color
  let color;
  if (type === 'herostone') {
    color = COLOR_OPTIONS[markerColorIdx]?.solid || COLOR_OPTIONS[0].solid;
  } else if (type === 'inscription') {
    color = COLOR_OPTIONS[markerColorIdx]?.solid || COLOR_OPTIONS[0].solid;
  } else {
    color = COLOR_OPTIONS[markerColorIdx]?.solid || COLOR_OPTIONS[0].solid;
  }
  // Font size logic matches temple clusters: depends on size and count length
  let fontSize;
  const countLength = String(count).length;
  if (size === 36) {
    fontSize = countLength === 1 ? 13 : countLength === 2 ? 10 : 8;
  } else if (size === 48) {
    fontSize = countLength === 1 ? 17 : countLength === 2 ? 13 : 10;
  } else {
    fontSize = countLength === 1 ? 22 : countLength === 2 ? 16 : 12;
  }
  if (type === 'inscription') {
    // Use same font size logic and center text at y=18 for best vertical alignment
    return L.divIcon({
      html: `<svg width="${size}" height="${size}" viewBox="0 0 36 36"><rect x="3" y="3" width="30" height="30" fill="${color}" stroke="#fff" stroke-width="1.5"/><text x="18" y="18" text-anchor="middle" font-size="${fontSize}" fill="#111" font-weight="bold" alignment-baseline="middle" dominant-baseline="middle" font-family="Arial, 'Helvetica Neue', Helvetica, sans-serif">${count}</text></svg>`,
      className: 'inscription-cluster-icon',
      iconSize: [size, size]
    });
  }
  // Default: circle for herostones, now using SVG for visual consistency
  return L.divIcon({
    html: `<svg width="${size}" height="${size}" viewBox="0 0 36 36"><circle cx="18" cy="18" r="15" fill="${color}" stroke="#fff" stroke-width="2"/><text x="18" y="18" text-anchor="middle" font-size="${fontSize}" fill="#111" font-weight="bold" alignment-baseline="middle" dominant-baseline="middle" font-family="Arial, 'Helvetica Neue', Helvetica, sans-serif">${count}</text></svg>`,
    className: 'herostone-cluster-icon',
    iconSize: [size, size]
  });
}

function getLatLng(item, type) {
  // For temples, use 'Latitude' and 'Longitude' columns explicitly
  if (type === 'temple') {
    let lat = item.Latitude ?? item.latitude ?? item.Lat ?? item.lat;
    let lng = item.Longitude ?? item.longitude ?? item.Lon ?? item.lon ?? item.Long ?? item.lng;
    return window.safeCoords(lat, lng);
  } else {
    let lat = item.Lat ?? item.lat ?? item.latitude ?? item.Latitude;
    let lng = item.Long ?? item.Lng ?? item.lng ?? item.lon ?? item.Lon ?? item.longitude ?? item.Longitude;
    return window.safeCoords(lat, lng);
  }
}

function getTooltip(item) {
  let tooltip = '';
  if (item["Type of Herostone"]) tooltip += `<b>${item["Type of Herostone"]}</b><br/>`;
  if (item["Period"]) tooltip += `Period: ${item["Period"]}<br/>`;
  if (item["Village"]) tooltip += `Village: ${item["Village"]}<br/>`;
  if (item["Script of the Inscription"]) {
    tooltip += `Script: ${item["Script of the Inscription"]}`;
  } else if (item["script"]) {
    tooltip += `Script: ${item["script"]}`;
  }
  return tooltip;
}

function MapComponent({ herostones, temples, inscriptions, showHerostones, showTemples, showInscriptions, opacity, basemap, clusteringHerostones, clusteringInscriptions, clusteringTemples, herostoneColor, herostoneSize, herostoneOpacity, inscriptionColor, inscriptionSize, inscriptionOpacity, templeColor, templeSize, templeOpacity, setSelectedSite, setSidebarOpen }) {
  // --- Tooltip for temples ---
  function getTempleTooltip(item) {
    let tooltip = '';
    if (item["Temple"]) tooltip += `<b>${item["Temple"]}</b><br/>`;
    if (item["Village"]) tooltip += `Village: ${item["Village"]}<br/>`;
    if (item["Taluk"]) tooltip += `Taluk: ${item["Taluk"]}<br/>`;
    if (item["District"]) tooltip += `District: ${item["District"]}<br/>`;
    if (item["Century"]) tooltip += `Century: ${item["Century"]}<br/>`;
    if (item["Online Link To Documentation"]) tooltip += `<a href="${item["Online Link To Documentation"]}" target="_blank" rel="noopener noreferrer">Documentation</a>`;
    return tooltip;
  }
  // --- Dynamic marker size scaling with zoom ---
  // If user has set a custom size (via UI), do not auto-scale that layer
  // Default: size=6 at zoom=7, scale linearly with zoom
  const defaultMarkerSize = 6;
  const defaultZoom = 8;
  // Track if user has set a custom size for each layer
  const userSetHerostoneSize = herostoneSize !== 6;
  const userSetInscriptionSize = inscriptionSize !== 6;
  const userSetTempleSize = templeSize !== 6;
  // Compute scaled size for current zoom
  // New scaling: size = 6 + (zoom - 8)
  const getScaledSize = (zoom) => Math.max(2, defaultMarkerSize + (zoom - defaultZoom));
  // Store current zoom in state
  const [currentZoom, setCurrentZoom] = React.useState(defaultZoom);

  // ...existing code...
  const [districtLayers, setDistrictLayers] = useState({});
  const [talukLayers, setTalukLayers] = useState({});

  // No need for useEffect to populate dropdowns; React renders options directly
  // ...existing code...
  // Dummy state to force rerender when spatial filter changes
  const [spatialFilterVersion, setSpatialFilterVersion] = useState(0);
  const maskLayer = useRef(null); // for polygon mask
  const mapRef = useRef(null);
  // Expose mapRef globally for highlightMapFeature
  window.mapRef = mapRef;
  // Define and expose spatialFilterPoly globally for consistent access
  const spatialFilterPoly = useRef(null);
  window.spatialFilterPoly = spatialFilterPoly;
  const sidebarRef = useRef(null);
  const drawCircleLayer = useRef(null);
  const drawMarkerLayer = useRef(null); // for coordinate mode marker
  const tileLayers = useRef({});
  // Store the current spatial filter polygon (null if none)
  // Removed invalid setFeaturesDropdownOpen and setForceUpdate calls here
  // --- Map Initialization ---
  useEffect(() => {
    if (!mapRef.current) {
      mapRef.current = L.map('map').setView([12.9716, 77.5946], 8);
      tileLayers.current = {
        default: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap contributors', opacity: 1 }),
        terrain: L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', { attribution: '© OpenTopoMap contributors', opacity: 1 }),
        satellite: L.tileLayer('https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap Satellite', opacity: 1 }),
        cawm: L.tileLayer('https://cawm.lib.uiowa.edu/tiles/{z}/{x}/{y}.png', {
          attribution: '© Consortium of Ancient World Mappers (CAWM)',
          opacity: 1,
          minZoom: 1,
          maxZoom: 11
        })
      };
      tileLayers.current.cawm.addTo(mapRef.current);
      sidebarRef.current = L.control.sidebar({ container: 'leaflet-sidebar', position: 'left' }).addTo(mapRef.current);
      // Listen for zoom events to update marker sizes efficiently
      // Throttle marker icon updates on zoom for performance
      let debounceTimeout = null;
      mapRef.current.on('zoomend', () => {
        if (debounceTimeout) clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
          const zoom = mapRef.current.getZoom();
          setCurrentZoom(zoom);
          if (window._allMarkers && Array.isArray(window._allMarkers) && mapRef.current) {
            const bounds = mapRef.current.getBounds();
            requestAnimationFrame(() => {
              window._allMarkers.forEach(marker => {
                if (marker && marker.options && marker.options.icon && marker._map) {
                  // Only update if marker is in current map bounds
                  const latlng = marker.getLatLng && marker.getLatLng();
                  if (!latlng || !bounds.contains(latlng)) return;
                  const type = marker.options.shape || marker.options.type;
                  let size = 6;
                  let currentIconSize = marker.options.icon && marker.options.icon.options && marker.options.icon.options.iconSize ? marker.options.icon.options.iconSize[0] : null;
                  if (type === 'herostone') {
                    size = userSetHerostoneSize ? herostoneSize : (!clusteringHerostones ? getScaledSize(zoom) : herostoneSize);
                    if (currentIconSize !== size) {
                      marker.setIcon(createDivIcon('dot', size, herostoneColor, herostoneOpacity, 'herostone'));
                    }
                  } else if (type === 'inscription') {
                    size = userSetInscriptionSize ? inscriptionSize : (!clusteringInscriptions ? getScaledSize(zoom) : inscriptionSize);
                    if (currentIconSize !== size) {
                      marker.setIcon(createDivIcon('square', size, inscriptionColor, inscriptionOpacity, 'inscription'));
                    }
                  } else if (type === 'temple') {
                    size = userSetTempleSize ? templeSize : (!clusteringTemples ? getScaledSize(zoom) : templeSize);
                    if (currentIconSize !== size) {
                      marker.setIcon(createDivIcon('hexagon', size, templeColor, templeOpacity, 'temple'));
                    }
                  }
                }
              });
            });
          }
        }, 150);
      });
      setCurrentZoom(mapRef.current.getZoom());
    }
  }, []);

  // --- Marker/Cluster rendering ---
  useEffect(() => {

    // --- Data layers ---
    const layers = [];
    if (showHerostones) layers.push({ data: herostones, shape: 'dot', type: 'herostone' });
    if (showTemples) layers.push({ data: temples, shape: 'hexagon', type: 'temple' });
    if (showInscriptions) layers.push({ data: inscriptions, shape: 'square', type: 'inscription' });

    // --- Apply spatial filter if present ---
    let turfRef = window.turf || window.Turf || null;
    let filterPoly = spatialFilterPoly.current;
    if (filterPoly && !turfRef && typeof turf !== 'undefined') turfRef = turf;

    // Remove existing markers and clusters
    if (!window._allMarkers) window._allMarkers = [];
    window._allMarkers.forEach(m => m.remove());
    window._allMarkers = [];
    if (window._markerClusterGroup && mapRef.current) {
      if (window._markerClusterGroup.templeClusterGroup) mapRef.current.removeLayer(window._markerClusterGroup.templeClusterGroup);
      if (window._markerClusterGroup.herostoneClusterGroup) mapRef.current.removeLayer(window._markerClusterGroup.herostoneClusterGroup);
      if (window._markerClusterGroup.inscriptionClusterGroup) mapRef.current.removeLayer(window._markerClusterGroup.inscriptionClusterGroup);
      window._markerClusterGroup = null;
    }

    // Per-layer clustering logic
    const doClusterHerostones = clusteringHerostones && window.L && window.L.markerClusterGroup;
    const doClusterInscriptions = clusteringInscriptions && window.L && window.L.markerClusterGroup;
    const doClusterTemples = clusteringTemples && window.L && window.L.markerClusterGroup;

    // Create cluster groups if needed, using per-layer color
    const templeClusterGroup = doClusterTemples ? window.L.markerClusterGroup({
      iconCreateFunction: cluster => createClusterIcon(cluster.getChildCount(), templeColor, 'temple'),
      zIndex: 200
    }) : null;
    const herostoneClusterGroup = doClusterHerostones ? window.L.markerClusterGroup({
      iconCreateFunction: cluster => createClusterIcon(cluster.getChildCount(), herostoneColor, 'herostone'),
      zIndex: 100
    }) : null;
    const inscriptionClusterGroup = doClusterInscriptions ? window.L.markerClusterGroup({
      iconCreateFunction: cluster => createClusterIcon(cluster.getChildCount(), inscriptionColor, 'inscription'),
      zIndex: 0
    }) : null;

    // For each visible layer, add markers either to cluster group or directly to map
    layers.forEach(({ data, shape, type }) => {
      data.forEach(item => {
        const latlng = getLatLng(item, type);
        if (!latlng) return;
        // If spatial filter is active, skip markers outside the polygon
        if (filterPoly && turfRef) {
          const pt = turfRef.point([latlng[1], latlng[0]]);
          if (!turfRef.booleanPointInPolygon(pt, filterPoly)) return;
        }
        let markerIcon, zIndexOffset = 0;
        // Determine marker size: user-set or auto-scaled (only for non-clustered)
        let size;
        let useClustering = false;
        if (type === 'herostone') {
          useClustering = clusteringHerostones;
          size = userSetHerostoneSize ? herostoneSize : (useClustering ? herostoneSize : getScaledSize(currentZoom));
          markerIcon = createDivIcon(shape, size, herostoneColor, herostoneOpacity, type);
          zIndexOffset = 100;
        } else if (type === 'inscription') {
          useClustering = clusteringInscriptions;
          size = userSetInscriptionSize ? inscriptionSize : (useClustering ? inscriptionSize : getScaledSize(currentZoom));
          markerIcon = createDivIcon(shape, size, inscriptionColor, inscriptionOpacity, type);
          zIndexOffset = 0;
        } else if (type === 'temple') {
          useClustering = clusteringTemples;
          size = userSetTempleSize ? templeSize : (useClustering ? templeSize : getScaledSize(currentZoom));
          markerIcon = createDivIcon(shape, size, templeColor, templeOpacity, type);
          zIndexOffset = 200;
        }
        let tooltip = type === 'temple' ? getTempleTooltip(item) : getTooltip(item);
        const marker = L.marker(latlng, { icon: markerIcon, shape, zIndexOffset });
        marker.bindTooltip(tooltip, { direction: 'top', sticky: true, offset: [0, -8] });
        marker.on('click', () => {
          if (typeof setSelectedSite === 'function') setSelectedSite(item);
          if (type === 'temple') {
            window.templeSidebarHtml = getTempleSidebar(item);
          }
          if (typeof setSidebarOpen === 'function') setSidebarOpen(true);
        });
        // Add marker to cluster group or map
        if (type === 'temple' && templeClusterGroup) {
          templeClusterGroup.addLayer(marker);
        } else if (type === 'herostone' && herostoneClusterGroup) {
          herostoneClusterGroup.addLayer(marker);
        } else if (type === 'inscription' && inscriptionClusterGroup) {
          inscriptionClusterGroup.addLayer(marker);
        } else {
          marker.addTo(mapRef.current);
        }
        window._allMarkers.push(marker);
      });
    });
    // Add cluster groups to map if they exist and the feature is visible
    if (showTemples && templeClusterGroup) templeClusterGroup.addTo(mapRef.current);
    if (showHerostones && herostoneClusterGroup) herostoneClusterGroup.addTo(mapRef.current);
    if (showInscriptions && inscriptionClusterGroup) inscriptionClusterGroup.addTo(mapRef.current);
    // Store for removal
    window._markerClusterGroup = { templeClusterGroup, herostoneClusterGroup, inscriptionClusterGroup };
    // Restore function
    window._restoreAllMarkers = function() {
      window._allMarkers.forEach(m => m.remove());
      window._allMarkers = [];
      layers.forEach(({data, shape}) => {
        data.forEach(item => {
          let lat = item.Lat ?? item.lat ?? item.latitude ?? item.Latitude;
          let lng = item.Long ?? item.Lng ?? item.lng ?? item.lon ?? item.Lon ?? item.longitude ?? item.Longitude;
          if (typeof lat === 'string') lat = parseFloat(lat);
          if (typeof lng === 'string') lng = parseFloat(lng);
          if (!isNaN(lat) && !isNaN(lng)) {
            const marker = L.marker([lat, lng], { icon: createDivIcon(shape), shape }).addTo(mapRef.current);
            window._allMarkers.push(marker);
          }
        });
      });
    };

    // --- Draw & Buffer enable/disable state ---
    if (!window._drawBufferEnabled) window._drawBufferEnabled = false;

    // Remove previous listeners to avoid duplicates (guard against undefined handler)
    if (mapRef.current && typeof window._onMapClickDrawCircle === 'function') {
      mapRef.current.off('click', window._onMapClickDrawCircle);
    }

    // --- Draw helpers ---
    function drawCircleAt(lat, lng, radiusKm) {
      // Remove previous circle
      if (drawCircleLayer.current) {
        mapRef.current.removeLayer(drawCircleLayer.current);
        drawCircleLayer.current = null;
      }
      // Remove previous marker (for coord mode)
      if (drawMarkerLayer.current) {
        mapRef.current.removeLayer(drawMarkerLayer.current);
        drawMarkerLayer.current = null;
      }
      // Draw circle (radius in km)
      drawCircleLayer.current = L.circle([lat, lng], {
        radius: radiusKm * 1000, // convert km to meters
        color: '#72383d',
        fillColor: '#72383d',
        fillOpacity: 0.18,
        weight: 2
      }).addTo(mapRef.current);
      window._lastDrawn = { lat, lng, radius: radiusKm };
    }

    function markCoordPoint(lat, lng) {
      if (drawMarkerLayer.current) {
        mapRef.current.removeLayer(drawMarkerLayer.current);
        drawMarkerLayer.current = null;
      }
      drawMarkerLayer.current = L.marker([lat, lng], {
        icon: L.divIcon({ className: 'custom-marker', iconSize: [18, 18], iconAnchor: [9, 9], html: getMarkerSVG('dot', 18, '#72383d', 1) })
      }).addTo(mapRef.current);
      mapRef.current.setView([lat, lng], 14);
      window._lastMarked = { lat, lng };
    }

    // --- Draw Circle Button ---
    const drawBtn = document.getElementById('draw-circle-btn');
    if (drawBtn) {
      drawBtn.onclick = function() {
        const method = document.getElementById('draw-method-random')?.checked ? 'random' : 'coord';
        const radius = parseFloat(document.getElementById('draw-radius')?.value || '1');
        if (isNaN(radius) || radius <= 0) return;
        if (method === 'random') {
          window._drawBufferEnabled = true;
          alert('Click on the map to select a center point.');
        } else {
          const lat = parseFloat(document.getElementById('draw-lat')?.value);
          const lng = parseFloat(document.getElementById('draw-lng')?.value);
          if (isNaN(lat) || isNaN(lng)) return;
          drawCircleAt(lat, lng, radius);
          window._drawBufferEnabled = false;
        }
      };
    }

    // --- Map click for Random mode ---
    function onMapClickDrawCircle(e) {
      if (!window._drawBufferEnabled) return;
      const method = document.getElementById('draw-method-random')?.checked ? 'random' : 'coord';
      if (method !== 'random') return;
      const radius = parseFloat(document.getElementById('draw-radius')?.value || '1');
      if (isNaN(radius) || radius <= 0) return;
      drawCircleAt(e.latlng.lat, e.latlng.lng, radius);
      window._drawBufferEnabled = false;
    }
    window._onMapClickDrawCircle = onMapClickDrawCircle;
    mapRef.current.on('click', onMapClickDrawCircle);

    // --- Mark Button for Coordinate mode ---
    const markBtn = document.querySelector('#draw-coord-fields button');
    if (markBtn) {
      markBtn.onclick = function() {
        const lat = parseFloat(document.getElementById('draw-lat')?.value);
        const lng = parseFloat(document.getElementById('draw-lng')?.value);
        if (isNaN(lat) || isNaN(lng)) return;
        markCoordPoint(lat, lng);
      };
    }

    // --- Update Button ---
    const updateBtn = document.getElementById('update-circle-btn');
    if (updateBtn) {
      updateBtn.onclick = function() {
        const method = document.getElementById('draw-method-random')?.checked ? 'random' : 'coord';
        const radius = parseFloat(document.getElementById('draw-radius')?.value || '1');
        let lat, lng;
        if (method === 'coord') {
          lat = parseFloat(document.getElementById('draw-lat')?.value);
          lng = parseFloat(document.getElementById('draw-lng')?.value);
        } else if (window._lastDrawn) {
          lat = window._lastDrawn.lat;
          lng = window._lastDrawn.lng;
        }
        if (isNaN(lat) || isNaN(lng) || isNaN(radius) || radius <= 0) return;
        drawCircleAt(lat, lng, radius);
      };
    }

    // --- Clear Button ---
    // Clear Button: also clears spatial filter
    {
      const clearBtn = document.getElementById('clear-circle-btn');
      if (clearBtn) {
        clearBtn.onclick = function() {
          if (drawCircleLayer.current) {
            mapRef.current.removeLayer(drawCircleLayer.current);
            drawCircleLayer.current = null;
          }
          if (drawMarkerLayer.current) {
            mapRef.current.removeLayer(drawMarkerLayer.current);
            drawMarkerLayer.current = null;
          }
          window._lastDrawn = null;
          window._lastMarked = null;
          // Remove mask if present
          if (typeof maskLayer !== 'undefined' && maskLayer.current) {
            mapRef.current.removeLayer(maskLayer.current);
            maskLayer.current = null;
          }
          // Clear spatial filter and rerender
          spatialFilterPoly.current = null;
          if (typeof window.forceMapUpdate === 'function') window.forceMapUpdate();
        };
      }
    }

    // --- Clip Button ---
    const clipBtn = document.getElementById('clip-circle-btn');
    if (clipBtn) {
      clipBtn.onclick = function() {
        // Always update the circle to match the latest UI values before clipping
        const method = document.getElementById('draw-method-random')?.checked ? 'random' : 'coord';
        const radius = parseFloat(document.getElementById('draw-radius')?.value || '1');
        let lat, lng;
        if (method === 'coord') {
          lat = parseFloat(document.getElementById('draw-lat')?.value);
          lng = parseFloat(document.getElementById('draw-lng')?.value);
        } else if (window._lastDrawn) {
          lat = window._lastDrawn.lat;
          lng = window._lastDrawn.lng;
        }
        let circleValid = false;
        if (!isNaN(lat) && !isNaN(lng) && !isNaN(radius) && radius > 0) {
          // Redraw the circle to match the latest values
          if (drawCircleLayer.current) {
            mapRef.current.removeLayer(drawCircleLayer.current);
            drawCircleLayer.current = null;
          }
          drawCircleLayer.current = L.circle([lat, lng], {
            radius: radius * 1000,
            color: '#72383d',
            fillColor: '#72383d',
            fillOpacity: 0.18,
            weight: 2
          }).addTo(mapRef.current);
          window._lastDrawn = { lat, lng, radius };
          circleValid = true;
        }
        // Only perform the spatial clip if the circle is present
        if (circleValid && drawCircleLayer.current) {
          if (typeof turf === 'undefined' && typeof window.turf === 'undefined') {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/@turf/turf@6.5.0/turf.min.js';
            script.onload = doSpatialClip;
            document.head.appendChild(script);
          } else {
            doSpatialClip();
          }
        }
      };
    }

    // --- Helper: Perform spatial clipping and update filter ---
    function doSpatialClip() {
      const turfRef = window.turf || turf;
      if (!drawCircleLayer.current) return;
      const circleLatLng = drawCircleLayer.current.getLatLng();
      const circleRadius = drawCircleLayer.current.getRadius(); // in meters
      // Create turf circle polygon and store as filter
      spatialFilterPoly.current = turfRef.circle([circleLatLng.lng, circleLatLng.lat], circleRadius / 1000, {steps: 64, units: 'kilometers'});
      setSpatialFilterVersion(v => v + 1); // force rerender
    }

    // --- Clear Button: also clears spatial filter ---
    const clearBtn = document.getElementById('clear-circle-btn');
    if (clearBtn) {
      clearBtn.onclick = function() {
        if (drawCircleLayer.current) {
          mapRef.current.removeLayer(drawCircleLayer.current);
          drawCircleLayer.current = null;
        }
        if (drawMarkerLayer.current) {
          mapRef.current.removeLayer(drawMarkerLayer.current);
          drawMarkerLayer.current = null;
        }
        window._lastDrawn = null;
        window._lastMarked = null;
        // Remove mask if present
        if (typeof maskLayer !== 'undefined' && maskLayer.current) {
          mapRef.current.removeLayer(maskLayer.current);
          maskLayer.current = null;
        }
      // Clear spatial filter and rerender
      spatialFilterPoly.current = null;
      setSpatialFilterVersion(v => v + 1); // force rerender
      };
    }
  }, [herostones, temples, inscriptions, showHerostones, showTemples, showInscriptions, clusteringHerostones, clusteringInscriptions, clusteringTemples, herostoneColor, herostoneSize, herostoneOpacity, inscriptionColor, inscriptionSize, inscriptionOpacity, templeColor, templeSize, templeOpacity, spatialFilterVersion, currentZoom]);

  // Handle basemap switching
  useEffect(() => {
    if (!mapRef.current || !tileLayers.current) return;
    Object.keys(tileLayers.current).forEach(key => {
      mapRef.current.removeLayer(tileLayers.current[key]);
    });
    tileLayers.current[basemap].setOpacity(opacity);
    tileLayers.current[basemap].addTo(mapRef.current);
  }, [basemap, opacity]);

  return (
    <>
      <div id="map"></div>
    </>
  );
}

function ChartComponent({ data }) {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (!chartRef.current) return;
    if (chartInstance.current) chartInstance.current.destroy();
    // Use the same marker/cluster colors as on the map
    const markerColors = [
      '#a259c4', // Herostones (Violet)
      '#f85032', // Inscriptions (Red)
      '#ffd200'  // Temples (Yellow)
    ];
    chartInstance.current = new Chart(chartRef.current, {
      type: 'doughnut',
      data: {
        labels: data.map(d => d.name),
        datasets: [{
          label: 'Heritage Sites',
          data: data.map(d => d.value || 1),
          backgroundColor: markerColors,
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: { enabled: true }
        },
        cutout: '65%'
      }
    });
  }, [data]);

  return <div style={{width: 240, height: 240, margin: '0 auto'}}><canvas ref={chartRef} width={240} height={240}></canvas></div>;
}

function RightSidebar({ selectedSite, data, show, onClose, herostones = [], inscriptions = [], temples = [], showHerostones = true, showInscriptions = true, showTemples = true, setSelectedSite, highlightMapFeature, spatialFilterVersion = 0, sidebarWidth = 350, setSidebarWidth }) {
  const [activeTab, setActiveTab] = React.useState('about');
  React.useEffect(() => {
    if (selectedSite) setActiveTab('about');
  }, [selectedSite]);
  // All hooks must be at the top
  const [featuresDropdownOpen, setFeaturesDropdownOpen] = React.useState({herostones: true, inscriptions: true, temples: true});
  const [, setForceUpdate] = React.useState(0);
  React.useEffect(() => {
    setFeaturesDropdownOpen({herostones: false, inscriptions: false, temples: false});
    setForceUpdate(v => v + 1);
  }, [spatialFilterVersion]);
  const showDefault = !selectedSite;
  // Show custom sidebar for temples if present
  const isTemple = selectedSite && selectedSite["Temple"];
  // Filter features by spatial clip (polygon) if present, matching map logic
  // Always recalculate filtered features on any relevant prop change
  let turfRef = window.turf || window.Turf || null;
  let filterPoly = window.spatialFilterPoly && window.spatialFilterPoly.current;
  if (filterPoly && !turfRef && typeof turf !== 'undefined') turfRef = turf;
  function isInsideClip(item, type) {
    if (!filterPoly || !turfRef) return true;
    let lat, lng;
    if (type === 'temple') {
      lat = item.Latitude ?? item.latitude ?? item.Lat ?? item.lat;
      lng = item.Longitude ?? item.longitude ?? item.Lon ?? item.lon ?? item.Long ?? item.lng;
    } else {
      lat = item.Lat ?? item.lat ?? item.latitude ?? item.Latitude;
      lng = item.Long ?? item.Lng ?? item.lng ?? item.lon ?? item.Lon ?? item.longitude ?? item.Longitude;
    }
    if (typeof lat === 'string') lat = parseFloat(lat);
    if (typeof lng === 'string') lng = parseFloat(lng);
    if (isNaN(lat) || isNaN(lng)) return false;
    const pt = turfRef.point([lng, lat]);
    return turfRef.booleanPointInPolygon(pt, filterPoly);
  }
  const filteredHerostones = showHerostones ? herostones.filter(h => isInsideClip(h, 'herostone')) : [];
  const filteredInscriptions = showInscriptions ? inscriptions.filter(i => isInsideClip(i, 'inscription')) : [];
  const filteredTemples = showTemples ? temples.filter(t => isInsideClip(t, 'temple')) : [];
  // Handler for clicking a feature item: select and highlight on map
  function handleItemClick(type, item, idx) {
    if (typeof setSelectedSite === 'function') setSelectedSite(item);
    if (typeof highlightMapFeature === 'function') highlightMapFeature(type, item, idx);
  }
  // Sidebar width state for resizable sidebar
  const sidebarRef = React.useRef(null);
  // Drag logic
  React.useEffect(() => {
    const handleMouseMove = e => {
      if (window._sidebarResizing) {
        const newWidth = Math.max(250, Math.min(700, window.innerWidth - e.clientX));
        if (typeof setSidebarWidth === 'function') setSidebarWidth(newWidth);
      }
    };
    const handleMouseUp = () => { window._sidebarResizing = false; };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [setSidebarWidth]);
  return (
    <div ref={sidebarRef} className={`offcanvas offcanvas-end${show ? ' show' : ''}`} tabIndex="-1" style={{visibility: show ? 'visible' : 'hidden', width: sidebarWidth, zIndex: 1050, height: '100vh', display: 'flex', flexDirection: 'column', transition: 'width 0.1s'}}>
      {/* Draggable resizer bar */}
      <div
        style={{position: 'absolute', left: -6, top: 0, width: 12, height: '100%', cursor: 'ew-resize', zIndex: 1100, background: 'transparent'}}
        onMouseDown={e => { window._sidebarResizing = true; e.preventDefault(); }}
        title="Drag to resize sidebar"
      />
      <div className="offcanvas-header" style={{flex: '0 0 auto'}}>
        <h5 className="offcanvas-title">Heritage Info</h5>
        <button type="button" className="btn-close" aria-label="Close" onClick={onClose}></button>
      </div>
      <div className="offcanvas-body p-0" style={{flex: '1 1 auto', overflowY: 'auto', minHeight: 0}}>
        <ul className="nav nav-tabs" id="sidebarTabs" role="tablist" aria-label="Sidebar Tabs">
          <li className="nav-item" role="presentation" style={{flex: 1, minWidth: 0}}>
            <button className={`nav-link${activeTab === 'about' ? ' active' : ''}`} id="about-tab" type="button" role="tab" aria-selected={activeTab === 'about'} aria-controls="about-panel" tabIndex={activeTab === 'about' ? 0 : -1} onClick={() => setActiveTab('about')} style={{fontSize: '0.97em', padding: '6px 8px', minWidth: 0, width: '100%'}}>About</button>
          </li>
          <li className="nav-item" role="presentation" style={{flex: 1, minWidth: 0}}>
            <button className={`nav-link${activeTab === 'features' ? ' active' : ''}`} id="features-tab" type="button" role="tab" aria-selected={activeTab === 'features'} aria-controls="features-panel" tabIndex={activeTab === 'features' ? 0 : -1} onClick={() => setActiveTab('features')} style={{fontSize: '0.97em', padding: '6px 8px', minWidth: 0, width: '100%'}}>Features</button>
          </li>
          <li className="nav-item" role="presentation" style={{flex: 1, minWidth: 0}}>
            <button className={`nav-link${activeTab === 'wiki' ? ' active' : ''}`} id="wiki-tab" type="button" role="tab" aria-selected={activeTab === 'wiki'} aria-controls="wiki-panel" tabIndex={activeTab === 'wiki' ? 0 : -1} onClick={() => setActiveTab('wiki')} style={{fontSize: '0.97em', padding: '6px 8px', minWidth: 0, width: '100%'}}>Wikipedia</button>
          </li>
          <li className="nav-item" role="presentation" style={{flex: 1, minWidth: 0}}>
            <button className={`nav-link${activeTab === 'photos' ? ' active' : ''}`} id="photos-tab" type="button" role="tab" aria-selected={activeTab === 'photos'} aria-controls="photos-panel" tabIndex={activeTab === 'photos' ? 0 : -1} onClick={() => setActiveTab('photos')} style={{fontSize: '0.97em', padding: '6px 8px', minWidth: 0, width: '100%'}}>Photos</button>
          </li>
        </ul>
        <div className="tab-content p-3" id="sidebarTabsContent">
          {activeTab === 'features' && (
            <div className="tab-pane fade show active" id="features-panel" role="tabpanel" aria-labelledby="features-tab">
              <div style={{marginBottom: '0.5em', color: '#888', fontSize: '10pt'}}>All visible map points are listed below. Click to highlight on the map.</div>
              {/* Features Dropdowns */}
              <div>
                {/* Herostones Dropdown */}
                <div style={{marginBottom: 8}}>
                  <div style={{cursor: 'pointer', fontWeight: 500, color: '#72383d', display: 'flex', alignItems: 'center'}} onClick={() => setFeaturesDropdownOpen(o => ({...o, herostones: !o.herostones}))}>
                    <span style={{marginRight: 6}}>{featuresDropdownOpen.herostones ? '▼' : '►'}</span>Herostones ({showHerostones ? filteredHerostones.length : 0})
                  </div>
                  {featuresDropdownOpen.herostones && showHerostones && (
                    <ul key={spatialFilterVersion + '-herostones'} style={{listStyle: 'none', margin: 0, padding: '4px 0 4px 16px'}}>
                      {filteredHerostones.map((h, idx) => (
                        <li key={h.id || idx} style={{cursor: 'pointer', padding: '2px 0', color: '#333'}} onClick={() => handleItemClick('herostone', h, idx)}>
                          {h.name || h.Site || h.Temple || h.Inscription || `Herostone #${idx+1}`}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                {/* Inscriptions Dropdown */}
                <div style={{marginBottom: 8}}>
                  <div style={{cursor: 'pointer', fontWeight: 500, color: '#72383d', display: 'flex', alignItems: 'center'}} onClick={() => setFeaturesDropdownOpen(o => ({...o, inscriptions: !o.inscriptions}))}>
                    <span style={{marginRight: 6}}>{featuresDropdownOpen.inscriptions ? '▼' : '►'}</span>Inscriptions ({showInscriptions ? filteredInscriptions.length : 0})
                  </div>
                  {featuresDropdownOpen.inscriptions && showInscriptions && (
                    <ul key={spatialFilterVersion + '-inscriptions'} style={{listStyle: 'none', margin: 0, padding: '4px 0 4px 16px'}}>
                      {filteredInscriptions.map((i, idx) => (
                        <li key={i.id || idx} style={{cursor: 'pointer', padding: '2px 0', color: '#333'}} onClick={() => handleItemClick('inscription', i, idx)}>
                          {i.name || i.Site || i.Temple || i.Inscription || `Inscription #${idx+1}`}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                {/* Temples Dropdown */}
                <div style={{marginBottom: 8}}>
                  <div style={{cursor: 'pointer', fontWeight: 500, color: '#72383d', display: 'flex', alignItems: 'center'}} onClick={() => setFeaturesDropdownOpen(o => ({...o, temples: !o.temples}))}>
                    <span style={{marginRight: 6}}>{featuresDropdownOpen.temples ? '▼' : '►'}</span>Temples ({showTemples ? filteredTemples.length : 0})
                  </div>
                  {featuresDropdownOpen.temples && showTemples && (
                    <ul key={spatialFilterVersion + '-temples'} style={{listStyle: 'none', margin: 0, padding: '4px 0 4px 16px'}}>
                      {filteredTemples.map((t, idx) => (
                        <li key={t.id || idx} style={{cursor: 'pointer', padding: '2px 0', color: '#333'}} onClick={() => handleItemClick('temple', t, idx)}>
                          {t.name || t.Site || t.Temple || t.Inscription || `Temple #${idx+1}`}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
              {/* Infographic/Chart for visible features */}
              <div style={{marginTop: 16, marginBottom: 8}}>
                <div style={{fontWeight: 600, color: '#72383d', marginBottom: 4}}>Infographic</div>
                <div style={{fontWeight: 500, color: '#555', fontSize: '1em', marginBottom: 6, textAlign: 'center'}}>Visible Heritage Features</div>
                <ChartComponent
                  data={[{ name: 'Herostones', value: filteredHerostones.length }, { name: 'Inscriptions', value: filteredInscriptions.length }, { name: 'Temples', value: filteredTemples.length }]}
                />
              </div>
            </div>
          )}
          {activeTab === 'about' && (
            <div className="tab-pane fade show active" id="about-panel" role="tabpanel" aria-labelledby="about-tab">
              {showDefault ? (
                <>
                  <h6>About The Mythic Society</h6>
                  <p>The Mythic Society is a historic academic institution in Bengaluru, founded in 1909, dedicated to research and preservation of Indian history, culture, and heritage.</p>
                  <p><b>Bengaluru Inscriptions 3D Digital Conservation Project:</b> Digitally conserves 1500 ancient stone inscriptions from Bengaluru and Ramanagara, making them accessible for research and public knowledge.</p>
                  <p><b>Akshara Bhandara:</b> A digital gateway to the rich world of ancient Kannada scripts, offering interactive tools, 3D scans, and educational resources for inscription studies.</p>
                </>
              ) : isTemple && window.templeSidebarHtml ? (
                // Sanitize HTML before rendering to prevent XSS
                <div dangerouslySetInnerHTML={{__html: window.DOMPurify ? window.DOMPurify.sanitize(window.templeSidebarHtml) : ''}} />
              ) : (
                <>
                  <h6>Feature Details</h6>
                  <div style={{maxHeight: '350px', overflow: 'auto'}}>
                    <table className="table table-sm table-bordered" style={{fontSize: '0.97em'}}>
                      <tbody>
                        {Object.entries(selectedSite).map(([key, value]) => (
                          <tr key={key}>
                            <th style={{verticalAlign: 'top', minWidth: 120}}>{key}</th>
                            <td>{String(value)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </div>
          )}
          {activeTab === 'wiki' && (
            <div className="tab-pane fade show active" id="wiki-panel" role="tabpanel" aria-labelledby="wiki-tab">
              {showDefault ? (
                <>
                  <p><a href="https://en.wikipedia.org/wiki/Daly_Memorial_Hall#Mythic_society" target="_blank" rel="noopener noreferrer">The Mythic Society Wikipedia</a></p>
                  <p><a href="https://www.wikidata.org/wiki/Q5211784" target="_blank" rel="noopener noreferrer">Wikidata: Q5211784</a></p>
                </>
              ) : (
                <p>Wikipedia info coming soon.</p>
              )}
            </div>
          )}
          {activeTab === 'photos' && (
            <div className="tab-pane fade show active" id="photos-panel" role="tabpanel" aria-labelledby="photos-tab">
              {showDefault ? (
                <>
                  <img src="https://mythicsociety.org/bsms_ci/assets/uploads/banner/p1.jpg" alt="Mythic Society Building" style={{width:'100%', marginBottom: '8px', borderRadius: '6px'}} />
                  <img src="https://mythicsociety.github.io/AksharaBhandara/assets/Home-image.png" alt="Akshara Bhandara" style={{width:'100%', marginBottom: '8px', borderRadius: '6px'}} />
                  <img src="https://mythicsociety.org/bsms_ci/assets/uploads/banner/talegari.JPG" alt="Inscriptions Project" style={{width:'100%', borderRadius: '6px'}} />
                </>
              ) : (
                <p>Photos coming soon.</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// SidebarPanel React component for sidebar controls
function SidebarPanel({
  showHerostones, setShowHerostones,
  showTemples, setShowTemples,
  showInscriptions, setShowInscriptions,
  opacity, setOpacity,
  basemap, setBasemap,
  clusteringHerostones, setClusteringHerostones,
  clusteringInscriptions, setClusteringInscriptions,
  clusteringTemples, setClusteringTemples,
  herostoneColor, setHerostoneColor,
  herostoneSize, setHerostoneSize,
  herostoneOpacity, setHerostoneOpacity,
  inscriptionColor, setInscriptionColor,
  inscriptionSize, setInscriptionSize,
  inscriptionOpacity, setInscriptionOpacity,
  templeColor, setTempleColor,
  templeSize, setTempleSize,
  templeOpacity, setTempleOpacity
}) {
  return (
    <div id="leaflet-sidebar" className="leaflet-sidebar collapsed">
      <div className="leaflet-sidebar-tabs">
        <ul role="tablist">
          <li><a href="#site" role="tab"><i className="fa fa-database"></i></a></li>
          <li><a href="#filters" role="tab"><i className="fa fa-filter"></i></a></li>
          <li><a href="#layers" role="tab"><i className="fa fa-layer-group"></i></a></li>
          <li><a href="#draw" role="tab"><i className="fa fa-draw-polygon"></i></a></li>
          {/* Move Feedback tab to the bottom */}
        </ul>
        <ul role="tablist" style={{position: 'absolute', bottom: 0, left: 0, width: '100%', background: 'none', border: 'none', margin: 0, padding: 0, display: 'flex', justifyContent: 'flex-end'}}>
          <li><a href="#feedback" role="tab"><i className="fa fa-envelope"></i></a></li>
        </ul>
      </div>
      <div className="leaflet-sidebar-content">
        <div className="leaflet-sidebar-pane" id="site">
          <h1 className="leaflet-sidebar-header">Data Selection<span className="leaflet-sidebar-close"></span></h1>
          <div style={{padding: '0.5em 0.5em 0.5em 0'}}>
            {/* Features Section */}
            <div style={{marginBottom: '1.2em'}}>
              <div style={{fontWeight: 600, marginBottom: '0.5em', color: '#72383d'}}>Features</div>
              {(() => {
                const [openPanel, setOpenPanel] = React.useState(null);
                const rowStyle = {display: 'grid', gridTemplateColumns: '28px 1fr 32px 48px', alignItems: 'center', gap: '0 10px', position: 'relative', minHeight: 36};
                const iconBtnStyle = {background: 'none', border: 'none', cursor: 'pointer', margin: 0, padding: 0, color: '#72383d', display: 'flex', alignItems: 'center', justifyContent: 'center', height: 28, width: 28};
                return (
                  <div style={{display: 'flex', flexDirection: 'column', gap: '10px'}}>
                    {/* Herostones row */}
                    <div style={rowStyle}>
                      <input id="herostones-toggle" name="herostones-toggle" type="checkbox" checked={showHerostones} onChange={e => setShowHerostones(e.target.checked)} aria-label="Show Herostones" />
                      <span style={{display: 'flex', alignItems: 'center'}}>
                        <svg width="18" height="18" viewBox="0 0 18 18" style={{display: 'inline-block', verticalAlign: 'middle', marginRight: 4}}>
                          <circle cx="9" cy="9" r="8" fill="#72383d" />
                        </svg>
                        Herostones
                      </span>
                      <button style={iconBtnStyle} title="Customize Herostones" onClick={() => setOpenPanel(openPanel === 'herostone' ? null : 'herostone')}><i className="fa fa-cog"></i></button>
                      <label className="switch" style={{marginBottom: 0, marginLeft: 'auto'}} title="Toggle clustering for Herostones">
                        <input type="checkbox" checked={clusteringHerostones} onChange={e => setClusteringHerostones(e.target.checked)} />
                        <span className="slider round"></span>
                      </label>
                      {openPanel === 'herostone' && (
                        <div id="herostone-custom-popup" style={{position: 'fixed', left: (document.getElementById('leaflet-sidebar')?.offsetWidth || 70) + 16, top: 140, zIndex: 2000, background: '#fff', border: '1px solid #ccc', borderRadius: 8, padding: 16, minWidth: 240, maxWidth: 320, boxShadow: '0 2px 16px rgba(0,0,0,0.18)', maxHeight: 350, overflowY: 'auto'}}>
                          <div style={{marginBottom: 10}}><b>Herostones Customization</b></div>
                          <div style={{marginBottom: 10}}>
                            <label style={{fontWeight: 'bold', color: '#72383d', marginRight: 8}}>Color:</label>
                            {COLOR_OPTIONS.map((opt, idx) => (
                              <button key={opt.name} style={{width: 24, height: 24, borderRadius: '50%', border: herostoneColor === idx ? '2px solid #333' : '1px solid #bbb', background: opt.gradient, cursor: 'pointer', marginRight: 4}} onClick={() => setHerostoneColor(idx)} title={opt.name} />
                            ))}
                          </div>
                          <div style={{marginBottom: 10}}>
                            <label style={{fontWeight: 500, color: '#72383d', minWidth: '90px'}}>Size</label>
                            <input type="range" min="8" max="36" value={herostoneSize} onChange={e => setHerostoneSize(Number(e.target.value))} style={{width: 100}} />
                            <span style={{marginLeft: 8}}>{herostoneSize}px</span>
                          </div>
                          <div>
                            <label style={{fontWeight: 500, color: '#72383d', minWidth: '90px'}}>Opacity</label>
                            <input type="range" min="10" max="100" value={Math.round(herostoneOpacity * 100)} onChange={e => setHerostoneOpacity(Number(e.target.value) / 100)} style={{width: 100}} />
                            <span style={{marginLeft: 8}}>{Math.round(herostoneOpacity * 100)}%</span>
                          </div>
                        </div>
                      )}
                    </div>
                    {/* Inscriptions row */}
                    <div style={rowStyle}>
                      <input id="inscriptions-toggle" name="inscriptions-toggle" type="checkbox" checked={showInscriptions} onChange={e => setShowInscriptions(e.target.checked)} aria-label="Show Inscriptions" />
                      <span style={{display: 'flex', alignItems: 'center'}}>
                        <svg width="18" height="18" viewBox="0 0 18 18" style={{display: 'inline-block', verticalAlign: 'middle', marginRight: 4}}>
                          <rect x="3" y="3" width="12" height="12" fill="#72383d" />
                        </svg>
                        Inscriptions
                      </span>
                      <button style={iconBtnStyle} title="Customize Inscriptions" onClick={() => setOpenPanel(openPanel === 'inscription' ? null : 'inscription')}><i className="fa fa-cog"></i></button>
                      <label className="switch" style={{marginBottom: 0, marginLeft: 'auto'}} title="Toggle clustering for Inscriptions">
                        <input type="checkbox" checked={clusteringInscriptions} onChange={e => setClusteringInscriptions(e.target.checked)} />
                        <span className="slider round"></span>
                      </label>
                      {openPanel === 'inscription' && (
                        <div id="inscription-custom-popup" style={{position: 'fixed', left: (document.getElementById('leaflet-sidebar')?.offsetWidth || 70) + 16, top: 140, zIndex: 2000, background: '#fff', border: '1px solid #ccc', borderRadius: 8, padding: 16, minWidth: 240, maxWidth: 320, boxShadow: '0 2px 16px rgba(0,0,0,0.18)', maxHeight: 350, overflowY: 'auto'}}>
                          <div style={{marginBottom: 10}}><b>Inscriptions Customization</b></div>
                          <div style={{marginBottom: 10}}>
                            <label style={{fontWeight: 'bold', color: '#72383d', marginRight: 8}}>Color:</label>
                            {COLOR_OPTIONS.map((opt, idx) => (
                              <button key={opt.name} style={{width: 24, height: 24, borderRadius: '50%', border: inscriptionColor === idx ? '2px solid #333' : '1px solid #bbb', background: opt.gradient, cursor: 'pointer', marginRight: 4}} onClick={() => setInscriptionColor(idx)} title={opt.name} />
                            ))}
                          </div>
                          <div style={{marginBottom: 10}}>
                            <label style={{fontWeight: 500, color: '#72383d', minWidth: '90px'}}>Size</label>
                            <input type="range" min="8" max="36" value={inscriptionSize} onChange={e => setInscriptionSize(Number(e.target.value))} style={{width: 100}} />
                            <span style={{marginLeft: 8}}>{inscriptionSize}px</span>
                          </div>
                          <div>
                            <label style={{fontWeight: 500, color: '#72383d', minWidth: '90px'}}>Opacity</label>
                            <input type="range" min="10" max="100" value={Math.round(inscriptionOpacity * 100)} onChange={e => setInscriptionOpacity(Number(e.target.value) / 100)} style={{width: 100}} />
                            <span style={{marginLeft: 8}}>{Math.round(inscriptionOpacity * 100)}%</span>
                          </div>
                        </div>
                      )}
                    </div>
                    {/* Temples row */}
                    <div style={rowStyle}>
                      <input id="temples-toggle" name="temples-toggle" type="checkbox" checked={showTemples} onChange={e => setShowTemples(e.target.checked)} aria-label="Show Ancient Temples" />
                      <span style={{display: 'flex', alignItems: 'center'}}>
                        <svg width="18" height="18" viewBox="0 0 18 18" style={{display: 'inline-block', verticalAlign: 'middle', marginRight: 4}}>
                          <polygon points="9,2 16,6.5 16,14 9,17 2,14 2,6.5" fill="#72383d" />
                        </svg>
                        Ancient Temples
                      </span>
                      <button style={iconBtnStyle} title="Customize Temples" onClick={() => setOpenPanel(openPanel === 'temple' ? null : 'temple')}><i className="fa fa-cog"></i></button>
                      <label className="switch" style={{marginBottom: 0, marginLeft: 'auto'}} title="Toggle clustering for Temples">
                        <input type="checkbox" checked={clusteringTemples} onChange={e => setClusteringTemples(e.target.checked)} />
                        <span className="slider round"></span>
                      </label>
                      {openPanel === 'temple' && (
                        <div id="temple-custom-popup" style={{position: 'fixed', left: (document.getElementById('leaflet-sidebar')?.offsetWidth || 70) + 16, top: 140, zIndex: 2000, background: '#fff', border: '1px solid #ccc', borderRadius: 8, padding: 16, minWidth: 240, maxWidth: 320, boxShadow: '0 2px 16px rgba(0,0,0,0.18)', maxHeight: 350, overflowY: 'auto'}}>
                          <div style={{marginBottom: 10}}><b>Temples Customization</b></div>
                          <div style={{marginBottom: 10}}>
                            <label style={{fontWeight: 'bold', color: '#72383d', marginRight: 8}}>Color:</label>
                            {COLOR_OPTIONS.map((opt, idx) => (
                              <button key={opt.name} style={{width: 24, height: 24, borderRadius: '50%', border: templeColor === idx ? '2px solid #333' : '1px solid #bbb', background: opt.gradient, cursor: 'pointer', marginRight: 4}} onClick={() => setTempleColor(idx)} title={opt.name} />
                            ))}
                          </div>
                          <div style={{marginBottom: 10}}>
                            <label style={{fontWeight: 500, color: '#72383d', minWidth: '90px'}}>Size</label>
                            <input type="range" min="8" max="36" value={templeSize} onChange={e => setTempleSize(Number(e.target.value))} style={{width: 100}} />
                            <span style={{marginLeft: 8}}>{templeSize}px</span>
                          </div>
                          <div>
                            <label style={{fontWeight: 500, color: '#72383d', minWidth: '90px'}}>Opacity</label>
                            <input type="range" min="10" max="100" value={Math.round(templeOpacity * 100)} onChange={e => setTempleOpacity(Number(e.target.value) / 100)} style={{width: 100}} />
                            <span style={{marginLeft: 8}}>{Math.round(templeOpacity * 100)}%</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })()}
            </div>
            {/* ...existing code... */}
            {/* Per-layer Clustering Section removed; now integrated with Features above */}
          </div>
        </div>
        <div className="leaflet-sidebar-pane" id="filters">
          <h1 className="leaflet-sidebar-header">Filters<span className="leaflet-sidebar-close"></span></h1>
          <div>Filters UI coming soon...</div>
        </div>
        <div className="leaflet-sidebar-pane" id="layers">
          <h1 className="leaflet-sidebar-header">Layers<span className="leaflet-sidebar-close"></span></h1>
          <div style={{padding: '0.5em 0.5em 0.5em 0'}}>
            {/* Basemap Section */}
            <div style={{marginBottom: '1.2em'}}>
              <div style={{fontWeight: 600, marginBottom: '0.5em', color: '#72383d'}}>Basemap</div>
              {/* Basemap Radios FIRST */}
              <div style={{display: 'flex', flexDirection: 'column', gap: '0.5em', marginBottom: '1em'}}>
                <label style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                  <input type="radio" name="basemap" checked={basemap === 'default'} onChange={() => setBasemap('default')} />
                  <span><i className="fa fa-map" style={{color: '#72383d'}}></i> Default</span>
                </label>
                <label style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                  <input type="radio" name="basemap" checked={basemap === 'terrain'} onChange={() => setBasemap('terrain')} />
                  <span><i className="fa fa-mountain" style={{color: '#72383d'}}></i> Terrain</span>
                </label>
                <label style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                  <input type="radio" name="basemap" checked={basemap === 'satellite'} onChange={() => setBasemap('satellite')} />
                  <span><i className="fa fa-globe" style={{color: '#72383d'}}></i> Satellite</span>
                </label>
                <label style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                  <input type="radio" name="basemap" checked={basemap === 'cawm'} onChange={() => setBasemap('cawm')} />
                  <span><i className="fa fa-university" style={{color: '#72383d'}}></i> CAWM Ancient World</span>
                </label>
              </div>
            </div>
            {/* Basemap Opacity Slider */}
            <div style={{display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '1.2em'}}>
              <label htmlFor="basemap-opacity" style={{fontWeight: 500, color: '#72383d', minWidth: '110px', textAlign: 'left'}}>Basemap Opacity</label>
              <input
                type="range"
                id="basemap-opacity"
                name="basemap-opacity"
                min="0"
                max="100"
                value={Math.round(opacity * 100)}
                onChange={e => setOpacity(Number(e.target.value) / 100)}
                style={{flex:  1, minWidth: 0, maxWidth: '180px'}}
                aria-label="Basemap Opacity"
              />
              <span id="basemap-opacity-value" style={{width: '38px', textAlign: 'right', color: '#72383d'}}>{Math.round(opacity * 100)}%</span>
            </div>
          </div>
        </div>
        <div className="leaflet-sidebar-pane" id="draw">
          <h1 className="leaflet-sidebar-header">Spatial Filter<span className="leaflet-sidebar-close"></span></h1>
          <div style={{padding: '0.5em 0.5em 0.5em 0', color: '#72383d', fontStyle: 'italic'}}>
            {/* Spatial filter UI coming soon... */}
            No spatial filter tools are currently available.
          </div>
        </div>
        {/* Move Feedback pane to the bottom */}
        <div className="leaflet-sidebar-pane" id="feedback">
          <h1 className="leaflet-sidebar-header">Feedback<span className="leaflet-sidebar-close"></span></h1>
          <div>Feedback UI coming soon...</div>
        </div>
      </div>
    </div>
  );
}

function App() {
  // --- Spatial filter version state (must be first!) ---
  const [spatialFilterVersion, setSpatialFilterVersion] = useState(0);

  // Highlight and zoom to marker on map when a feature is clicked in Features tab
  function highlightMapFeature(type, item, idx) {
    // Try to find the marker on the map and open its popup, zoom in, and add a highlight effect
    if (!window.L || !window.mapRef || !window.mapRef.current) return;
    const map = window.mapRef.current;
    let lat = item.Latitude || item.latitude || item.Lat || item.lat;
    let lng = item.Longitude || item.longitude || item.Lon || item.lon || item.Long || item.lng;
    if (typeof lat === 'string') lat = parseFloat(lat);
    if (typeof lng === 'string') lng = parseFloat(lng);
    if (isNaN(lat) || isNaN(lng)) return;
    // Zoom to marker
    map.setView([lat, lng], 17, { animate: true });
    // Try to open the marker's popup if found
    if (Array.isArray(window._allMarkers)) {
      for (const marker of window._allMarkers) {
        const markerLatLng = marker.getLatLng && marker.getLatLng();
        if (markerLatLng && Math.abs(markerLatLng.lat - lat) < 1e-6 && Math.abs(markerLatLng.lng - lng) < 1e-6) {
          if (marker.openPopup) marker.openPopup();
          break;
        }
      }
    }
    // Add a highlight circle
    if (window._featureHighlightLayer) {
      map.removeLayer(window._featureHighlightLayer);
      window._featureHighlightLayer = null;
    }
    window._featureHighlightLayer = window.L.circle([lat, lng], {
      radius: 40,
      color: '#ff0',
      weight: 4,
      fillColor: '#ff0',
      fillOpacity: 0.25,
      pane: 'markerPane',
      interactive: false
    }).addTo(map);
    // Remove highlight after 2.5s
    setTimeout(() => {
      if (window._featureHighlightLayer) {
        map.removeLayer(window._featureHighlightLayer);
        window._featureHighlightLayer = null;
      }
    }, 2500);
  }
  // --- Data state ---
  const [herostones, setHerostones] = useState([]);
  const [temples, setTemples] = useState([]);
  const [inscriptions, setInscriptions] = useState([]);

  // --- UI state ---
  const [showHerostones, setShowHerostones] = useState(true);
  const [showTemples, setShowTemples] = useState(true); // temples ON by default
  const [showInscriptions, setShowInscriptions] = useState(true); // inscriptions ON by default
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedSite, setSelectedSite] = useState(null);
  // Sidebar width state for resizable sidebar (lifted to App)
  const [sidebarWidth, setSidebarWidth] = useState(350);

  // --- Marker/Map state ---
  const [opacity, setOpacity] = useState(1); // 0-1
  const [basemap, setBasemap] = useState('cawm');
  // Per-layer clustering toggles
  const [clusteringHerostones, setClusteringHerostones] = useState(false);
  const [clusteringInscriptions, setClusteringInscriptions] = useState(false);
  const [clusteringTemples, setClusteringTemples] = useState(false);
  // ...existing code...
  // Named locations for spatial queries (lng, lat)
  const namedLocations = {
    "Cubbon Park": [77.5946, 12.9763],
    "Bengaluru": [77.5946, 12.9716],
    // Add more as needed
  };

  // Example: AI query handler using global handleUserQuery
  async function onUserQuery(query, herostones, temples) {
    // Combine all features into GeoJSON-like array
    const features = [
      ...herostones.map(h => ({ geometry: { coordinates: [h.Longitude || h.lng || h.Lon || h.lon, h.Latitude || h.lat || h.Lon] }, properties: h })),
      ...temples.map(t => ({ geometry: { coordinates: [t.Longitude || t.lng || t.Lon || t.lon, t.Latitude || t.lat || t.Lon] }, properties: t })),
      // ...add inscriptions if needed
    ];
    if (window.handleUserQuery) {
      const results = await window.handleUserQuery(query, features, namedLocations);
      // For demo: log results, or update map/highlight as needed
      console.log('AI query results:', results);
      // TODO: Highlight or zoom to these features on the map
    } else {
      console.warn('AI handler not loaded');
    }
  }

  // Per-layer marker/cluster customization state
  const [herostoneColor, setHerostoneColor] = useState(0);
  const [herostoneSize, setHerostoneSize] = useState(6);
  const [herostoneOpacity, setHerostoneOpacity] = useState(0.6);
  const [inscriptionColor, setInscriptionColor] = useState(1);
  const [inscriptionSize, setInscriptionSize] = useState(6);
  const [inscriptionOpacity, setInscriptionOpacity] = useState(0.6);
  const [templeColor, setTempleColor] = useState(4);
  const [templeSize, setTempleSize] = useState(6);
  const [templeOpacity, setTempleOpacity] = useState(0.6);

  // Load Herostones CSV from Google Sheets using PapaParse
  const [dataError, setDataError] = useState(null);
  useEffect(() => {
    const url = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRHCFT5jA5VPInkSC9eqeDSJ43pEbAh0zFoz31CFn876VzFuUFobc9nTc1J068ilw/pub?gid=115817771&single=true&output=csv';
    const url2 = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSXXg4VXox3vI4MDq72UImHgMdTADZVFDX0kSHIZqqw0ZAq2FTaj2JHXkvvBdksKDh_2ysT9AseQqUl/pub?output=csv';
    const url3 = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRmsBKzbk4bkTTFvv3CUEmTnQd6mqQfdkixHmMkdH4jYpQTMj7w-3SXPeryptu9aXEjtw3EQxJpHK3d/pub?output=csv';
    let cancelled = false;
    async function loadData() {
      try {
        const [herostonesData, templesData, inscriptionsData] = await Promise.all([
          fetchCSV(url),
          fetchCSV(url2),
          fetchCSV(url3)
        ]);
        if (!cancelled) {
          setHerostones(herostonesData);
          setTemples(templesData);
          setInscriptions(inscriptionsData);
        }
      } catch (e) {
        console.error('Failed to load one or more datasets', e);
        if (!cancelled) setDataError('Failed to load one or more datasets');
      }
    }
    loadData();
    return () => { cancelled = true; };
  }, []);

  // Deselect site when sidebar is closed
  useEffect(() => {
    if (!sidebarOpen) setSelectedSite(null);
  }, [sidebarOpen]);

  // Combine visible data for the map
  const mapData = [
    ...(showHerostones ? herostones : []),
    ...(showTemples ? temples : []),
    ...(showInscriptions ? inscriptions : [])
  ];

  // --- Chat input state for AI queries ---
  const [chatInput, setChatInput] = useState("");
  const [chatResults, setChatResults] = useState([]);
  const [aiMode, setAiMode] = useState('rule'); // 'rule' or 'webllm'
  const [loadingLLM, setLoadingLLM] = useState(false);

  // Handler for chat submit
  async function handleChatSubmit(e) {
    e.preventDefault();
    if (!chatInput.trim()) return;
    const features = [
      ...herostones.map(h => ({ geometry: { coordinates: [h.Longitude || h.lng || h.Lon || h.lon, h.Latitude || h.lat || h.Lon] }, properties: h })),
      ...temples.map(t => ({ geometry: { coordinates: [t.Longitude || t.lng || t.Lon || t.lon, t.Latitude || t.lat || t.Lon] }, properties: t })),
    ];
    const namedLocations = {
      "Cubbon Park": [77.5946, 12.9763],
      "Bengaluru": [77.5946, 12.9716],
    };
    let aiResult = { mode: 'rule', result: '' };
    if (aiMode === 'webllm') {
      if (!window.webllmEnabled || !window.webllmEngine) {
        setChatResults(r => [...r, { user: chatInput, ai: 'Smart AI is still loading or unavailable. Please wait for WebLLM to finish loading, or check your browser compatibility.', mode: 'webllm' }]);
        setChatInput("");
        return;
      }
      aiResult = await window.webllmEngine.chat({ message: chatInput });
    } else {
      if (window.hybridAIQuery) {
        aiResult = await window.hybridAIQuery(chatInput, features, namedLocations);
        // For Basic mode, if any field is matched, show a summary of what was matched
        if (
          aiMode === 'rule' &&
          aiResult && aiResult.result &&
          typeof aiResult.result === 'object'
        ) {
          const { type, subtype, location, distance } = aiResult.result;
          if (type || subtype || location || distance) {
            let summary = 'Matched:';
            if (type) summary += ` Type: ${type}.`;
            if (subtype) summary += ` Subtype: ${subtype}.`;
            if (location) summary += ` Location: ${location}.`;
            if (distance) summary += ` Distance: ${distance}m.`;
            aiResult.result = summary;
          } else {
            aiResult.result = 'Sorry, I could not understand your request. Please try different keywords or check for typos.';
          }
        }
      } else {
        aiResult = { mode: aiMode, result: 'No AI available.' };
      }
    }
    setChatResults(r => [...r, { user: chatInput, ai: aiResult.result, mode: aiResult.mode }]);
    setChatInput("");
  }

  // State to control AI popup visibility
  const [showAIPopup, setShowAIPopup] = useState(false);

  return (
    <>
      <nav className="navbar" style={{justifyContent: 'flex-start', position: 'relative', display: 'flex', alignItems: 'center'}}>
        <img
          src="assets/Mythic Society Logo.jpg"
          alt="Mythic Society Logo"
          className="navbar-logo"
          style={{marginLeft: '15px'}}
        />
        <div style={{marginLeft: '25px', display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
          <span style={{fontSize: '1.72rem', fontWeight: 700, lineHeight: 1, color: '#fff', letterSpacing: '1px'}}>The Mythic Society</span>
          <span style={{fontSize: '0.95rem', color: '#fff', opacity: 0.85, fontWeight: 400, marginTop: '2px'}}>Nrupatunga Road, Bengaluru - 01</span>
        </div>
        {/* Centered duplicate */}
        <div style={{position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)', display: 'flex', flexDirection: 'column', alignItems: 'center', pointerEvents: 'none', zIndex: 1}}>
          <span style={{fontSize: '1.62rem', fontWeight: 400, lineHeight: 1, color: '#fff', letterSpacing: '1px', textAlign: 'center'}}>Bengaluru Heritage Sites</span>
          <span style={{fontSize: '0.95rem', color: '#fff', opacity: 0.85, fontWeight: 400, marginTop: '2px', textAlign: 'center'}}>Herostones | Inscriptions | Temples</span>
        </div>
        <div style={{marginLeft: 'auto', display: 'flex', flexDirection: 'column', alignItems: 'flex-end', justifyContent: 'center'}}>
          <span style={{fontSize: '1.05rem', color: '#fff', opacity: 0.85, fontWeight: 700, marginTop: '2px'}}>The Mythic Society</span>
          <span style={{fontSize: '1.05rem', color: '#fff', opacity: 0.85, fontWeight: 700, marginTop: '2px'}}>Bengaluru Inscriptions 3D Digital Conservation Project</span>
        </div>
      </nav>
      <div className="container mt-3">
        {/* Floating AI Button (bottom right) */}
        <button
          className="btn btn-theme d-flex align-items-center justify-content-center"
          style={{
            position: 'fixed',
            bottom: 30,
            right: sidebarOpen ? (sidebarWidth + 30) : 30,
            borderRadius: '50%',
            width: 54,
            height: 54,
            fontSize: '2rem',
            background: '#fff',
            color: '#72383d',
            border: '2.5px solid #72383d',
            boxShadow: '0 2px 12px rgba(0,0,0,0.13)',
            zIndex: 2100,
            transition: 'right 0.3s, bottom 0.2s'
          }}
          title="Ask Bengaluru Heritage AI"
          onClick={() => setShowAIPopup(true)}
          aria-label="Ask Bengaluru Heritage AI"
        >
          <i className="fa fa-robot" aria-hidden="true"></i>
        </button>
        {/* AI Chat Popup (hidden by default, shown on button click) */}
        {showAIPopup && (
          <div
            style={{
              position: 'fixed',
              left: '50%',
              bottom: 30,
              transform: 'translateX(-50%)',
              zIndex: 2000,
              width: 600,
              maxWidth: '98vw',
              background: 'linear-gradient(120deg,#f8f8fa 60%,#f3f3f7 100%)',
              border: '1.5px solid #e0e0e0',
              borderRadius: 18,
              boxShadow: '0 4px 32px 0 rgba(0,0,0,0.18)',
              padding: 0,
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
            }}
          >
            {/* Header */}
            <div style={{display: 'flex', alignItems: 'center', background: '#fff', borderBottom: '1px solid #eee', padding: '14px 18px 10px 18px'}}>
              <i className="fa fa-robot" style={{color: '#72383d', fontSize: '1.3rem', marginRight: 10}}></i>
              <span style={{fontWeight: 700, color: '#333', fontSize: '1.08rem', flex: 1}}>Ask Bengaluru Heritage AI</span>
              <button
                onClick={() => setShowAIPopup(false)}
                style={{background: 'none', border: 'none', color: '#888', fontSize: '1.25rem', marginLeft: 8, cursor: 'pointer', padding: 2}}
                title="Close"
                aria-label="Close AI Chat"
              >
                <i className="fa fa-times"></i>
              </button>
            </div>
            {/* Chat area */}
            <div style={{flex: 1, background: 'transparent', padding: '18px 18px 0 18px', maxHeight: 260, overflowY: 'auto', fontSize: '1.01rem', display: 'flex', flexDirection: 'column', gap: 10}}>
              {chatResults.length === 0 && (
                <div style={{color: '#aaa', textAlign: 'center', marginTop: 30, fontSize: '1.05em'}}>Start a conversation about Bengaluru's heritage...</div>
              )}
              {chatResults.map((msg, idx) => (
                <div key={idx} style={{display: 'flex', flexDirection: 'column', gap: 2}}>
                  <div style={{alignSelf: 'flex-end', background: '#e6f0ea', color: '#333', borderRadius: 12, padding: '7px 13px', maxWidth: '85%', fontWeight: 500, boxShadow: '0 1px 4px rgba(0,0,0,0.04)'}}>{msg.user}</div>
                  <div style={{alignSelf: 'flex-start', background: '#fff', color: '#72383d', borderRadius: 12, padding: '7px 13px', maxWidth: '85%', fontWeight: 500, boxShadow: '0 1px 4px rgba(0,0,0,0.04)'}}>
                    <span style={{fontWeight: 600, fontSize: '0.97em', marginRight: 6}}><i className="fa fa-robot" style={{marginRight: 4}}></i>AI:</span> {msg.ai}
                  </div>
                </div>
              ))}
            </div>
            {/* Input area */}
            <form onSubmit={handleChatSubmit} style={{display: 'flex', alignItems: 'center', gap: 8, background: '#f7f7fa', borderTop: '1px solid #eee', padding: '12px 14px'}}>
              <input
                type="text"
                value={chatInput}
                onChange={e => setChatInput(e.target.value)}
                placeholder="Type your question..."
                style={{flex: 1, border: 'none', outline: 'none', background: 'transparent', fontSize: '1.08em', padding: '7px 2px'}}
                autoFocus
              />
              <button type="submit" className="btn btn-theme" style={{padding: '6px 18px', borderRadius: 8, fontWeight: 600, fontSize: '1em', background: '#72383d', color: '#fff', border: 'none', boxShadow: '0 1px 4px rgba(0,0,0,0.04)'}}>Send</button>
              {/* Toggle Switch for Smart AI */}
              <label style={{display: 'flex', alignItems: 'center', marginLeft: 8, userSelect: 'none', cursor: loadingLLM ? 'not-allowed' : 'pointer', fontSize: '0.97em'}} title="Toggle Smart AI (WebLLM)">
                <span style={{marginRight: 4, color: aiMode === 'rule' ? '#72383d' : '#888'}}>Basic</span>
                <span style={{position: 'relative', display: 'inline-block', width: 32, height: 18, marginRight: 4}}>
                  <input
                    type="checkbox"
                    checked={aiMode === 'webllm'}
                    disabled={loadingLLM}
                    onChange={async e => {
                      if (e.target.checked) {
                        setLoadingLLM(true);
                        if (window.enableWebLLM) {
                          await window.enableWebLLM();
                          if (window.webllmEnabled && window.webllmEngine) {
                            setAiMode('webllm');
                          } else {
                            alert('WebLLM could not be loaded. Please check your browser compatibility.');
                            setAiMode('rule');
                          }
                        } else {
                          alert('WebLLM loader not found.');
                          setAiMode('rule');
                        }
                        setLoadingLLM(false);
                      } else {
                        setAiMode('rule');
                      }
                    }}
                    style={{opacity: 0, width: 0, height: 0, position: 'absolute'}}
                  />
                  <span style={{
                    position: 'absolute',
                    cursor: loadingLLM ? 'not-allowed' : 'pointer',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    background: aiMode === 'webllm' ? '#72383d' : '#ccc',
                    borderRadius: 10,
                    transition: 'background 0.2s'
                  }}></span>
                  <span style={{
                    position: 'absolute',
                    left: aiMode === 'webllm' ? 16 : 2,
                    top: 2,
                    width: 14,
                    height: 14,
                    background: '#fff',
                    borderRadius: '50%',
                    boxShadow: '0 1px 4px rgba(0,0,0,0.10)',
                    transition: 'left 0.2s'
                  }}></span>
                </span>
                <span style={{color: aiMode === 'webllm' ? '#72383d' : '#888'}}>Smart</span>
              </label>
            </form>
          </div>
        )}
        <div
          className="more-info-btn-container"
          style={{
            position: 'absolute',
            right: sidebarOpen ? `${sidebarWidth}px` : '30px',
            zIndex: 1100,
            transition: sidebarOpen ? 'none' : 'right 0.3s'
          }}
        >
          <button
            className="btn btn-theme d-flex align-items-center justify-content-center"
            style={{
              height: '37.5px',
              width: '37.5px',
              borderRadius: '50%',
              padding: 0,
              fontSize: '1.65rem',
              minWidth: 'unset',
              border: '3px solid #fff',
              boxShadow: '0 0 0 4px #fff, 0 1px 4px rgba(0,0,0,0.10)'
            }}
            aria-label="More Info"
            onClick={() => setSidebarOpen(o => !o)}
          >
            <i className="fa fa-info" aria-hidden="true" style={{display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', height: '100%', lineHeight: '37.5px', textAlign: 'center'}}></i>
          </button>
        </div>
        {/* Set map background to white if basemap opacity is 0 */}
        <style>{`#map { background: ${opacity === 0 ? '#fff' : 'transparent'} !important; }`}</style>
        <div style={{background: opacity === 0 ? '#fff' : 'transparent', borderRadius: 8}}>
          <SidebarPanel
            showHerostones={showHerostones}
            setShowHerostones={setShowHerostones}
            showTemples={showTemples}
            setShowTemples={setShowTemples}
            showInscriptions={showInscriptions}
            setShowInscriptions={setShowInscriptions}
            opacity={opacity}
            setOpacity={setOpacity}
            basemap={basemap}
            setBasemap={setBasemap}
            clusteringHerostones={clusteringHerostones}
            setClusteringHerostones={setClusteringHerostones}
            clusteringInscriptions={clusteringInscriptions}
            setClusteringInscriptions={setClusteringInscriptions}
            clusteringTemples={clusteringTemples}
            setClusteringTemples={setClusteringTemples}
            herostoneColor={herostoneColor}
            setHerostoneColor={setHerostoneColor}
            herostoneSize={herostoneSize}
            setHerostoneSize={setHerostoneSize}
            herostoneOpacity={herostoneOpacity}
            setHerostoneOpacity={setHerostoneOpacity}
            inscriptionColor={inscriptionColor}
            setInscriptionColor={setInscriptionColor}
            inscriptionSize={inscriptionSize}
            setInscriptionSize={setInscriptionSize}
            inscriptionOpacity={inscriptionOpacity}
            setInscriptionOpacity={setInscriptionOpacity}
            templeColor={templeColor}
            setTempleColor={setTempleColor}
            templeSize={templeSize}
            setTempleSize={setTempleSize}
            templeOpacity={templeOpacity}
            setTempleOpacity={setTempleOpacity}
          />
          <MapComponent
            herostones={herostones}
            temples={temples}
            inscriptions={inscriptions}
            showHerostones={showHerostones}
            showTemples={showTemples}
            showInscriptions={showInscriptions}
            opacity={opacity}
            basemap={basemap}
            clusteringHerostones={clusteringHerostones}
            clusteringInscriptions={clusteringInscriptions}
            clusteringTemples={clusteringTemples}
            herostoneColor={herostoneColor}
            herostoneSize={herostoneSize}
            herostoneOpacity={herostoneOpacity}
            inscriptionColor={inscriptionColor}
            inscriptionSize={inscriptionSize}
            inscriptionOpacity={inscriptionOpacity}
            templeColor={templeColor}
            templeSize={templeSize}
            templeOpacity={templeOpacity}
            setSelectedSite={setSelectedSite}
            setSidebarOpen={setSidebarOpen}
          />
          <RightSidebar
            key={spatialFilterVersion}
            selectedSite={selectedSite}
            data={mapData}
            show={sidebarOpen}
            onClose={() => setSidebarOpen(false)}
            herostones={herostones}
            inscriptions={inscriptions}
            temples={temples}
            showHerostones={showHerostones}
            showInscriptions={showInscriptions}
            showTemples={showTemples}
            setSelectedSite={setSelectedSite}
            highlightMapFeature={highlightMapFeature}
            spatialFilterVersion={spatialFilterVersion}
            sidebarWidth={sidebarWidth}
            setSidebarWidth={setSidebarWidth}
          />
        </div>
      </div>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
